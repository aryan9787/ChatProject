#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

/**
 * @brief Predefined pool of names for synthetic data generation.
 * 
 * All names are exactly of length 10 characters to ensure uniformity
 * during sorting experiments (especially for radix sort on strings).
 */
vector<string> namePool = {
    "Riyanshika",
    "Samanvitha",
    "Shreyanshi",
    "Siddhiksha",
    "Shreeyansh",
    "Sharmistha",
    "Jaivardhan",
    "Yashvardha",
    "Dakshayani",
    "Shamsheraa",
    "Krithikesh",
    "Prithviraj",
    "Hrishikesh",
    "Dhanashree",
    "Parikshith"
};

/**
 * @brief Generates a synthetic dataset CSV file of size n.
 * 
 * This function creates a CSV file containing 10 datasets (SetNo = 1 to 10),
 * each having n records. Each record consists of:
 * - A dataset number (SetNo)
 * - A randomly selected name from the name pool
 * - A randomly generated age between 10 and 20
 * 
 * @param n Number of records per dataset (total records = 10 * n)
 * 
 * @details
 * Output file format:
 * inputdata/data_nX.csv where X = n
 * 
 * CSV Structure:
 * SetNo,Name,Age
 * 1,Name1,Age1
 * ...
 */
void generateData(int n)
{
    string fileName = "inputdata/data_n" + to_string(n) + ".csv";
    ofstream file(fileName);

    if (!file.is_open())
    {
        cout << "Error creating file: " << fileName << endl;
        return;
    }

    file << "SetNo,Name,Age\n";

    for (int i = 1; i <= 10; i++)
    {
        for (int j = 0; j < n; j++)
        {
            string name = namePool[rand() % namePool.size()];
            int age = 10 + rand() % 11; // Generates age in range [10, 20]

            file << i << "," << name << "," << age << "\n";
        }
    }

    file.close();
}

/**
 * @brief Main function to drive dataset generation.
 * 
 * Initializes the random seed using current time and generates
 * multiple CSV files with increasing dataset sizes.
 * 
 * @return int Returns 0 on successful execution.
 * 
 * @details
 * Generates files for:
 * n = 10, 20, 30, ..., 100
 * 
 * Each file contains 10 datasets, each with n records.
 */
int main()
{
    srand(time(0));  // Seed random number generator

    for (int i = 10; i <= 100; i += 10)
    {
        generateData(i);
    }

    cout << "Synthetic CSV files generated successfully.\n";
    return 0;
}
