#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>

using namespace std;
using namespace chrono;

/**
 * @brief Structure to store a person's data
 */
struct Person {
    string name; // Name of the person
    int age;     // Age of the person
};

/**
 * @brief Comparator to sort by age
 */
bool cmpAge(const Person &a, const Person &b) {
    return a.age < b.age;
}

/**
 * @brief Comparator to sort by name
 */
bool cmpName(const Person &a, const Person &b) {
    return a.name < b.name;
}

/**
 * @brief Comparator to sort by name, then age
 */
bool cmpNameAge(const Person &a, const Person &b) {
    if (a.name != b.name) return a.name < b.name;
    return a.age < b.age;
}

/**
 * @brief Performs insertion sort using a comparator
 * @param arr Vector of Person
 * @param cmp Comparator function
 */
void insertionSort(vector<Person> &arr, bool (*cmp)(const Person&, const Person&)) {
    for (int i = 1; i < arr.size(); i++) {
        Person key = arr[i];
        int j = i - 1;

        while (j >= 0 && cmp(key, arr[j])) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

/**
 * @brief Merge step for merge sort
 */
void merge(vector<Person> &arr, int l, int m, int r,
           bool (*cmp)(const Person&, const Person&)) {

    vector<Person> L(arr.begin()+l, arr.begin()+m+1);
    vector<Person> R(arr.begin()+m+1, arr.begin()+r+1);

    int i=0,j=0,k=l;

    while(i<L.size() && j<R.size())
        arr[k++] = cmp(L[i],R[j]) ? L[i++] : R[j++];

    while(i<L.size()) arr[k++] = L[i++];
    while(j<R.size()) arr[k++] = R[j++];
}

/**
 * @brief Recursive merge sort implementation
 */
void mergeSort(vector<Person> &arr, int l, int r,
               bool (*cmp)(const Person&, const Person&)) {
    if(l>=r) return;
    int m=(l+r)/2;
    mergeSort(arr,l,m,cmp);
    mergeSort(arr,m+1,r,cmp);
    merge(arr,l,m,r,cmp);
}

/**
 * @brief Partition function for quick sort
 */
int partition(vector<Person> &arr,int low,int high,
              bool (*cmp)(const Person&, const Person&)) {
    Person pivot=arr[high];
    int i=low-1;

    for(int j=low;j<high;j++) {
        if(cmp(arr[j],pivot)) {
            i++;
            swap(arr[i],arr[j]);
        }
    }
    swap(arr[i+1],arr[high]);
    return i+1;
}

/**
 * @brief Quick sort implementation
 */
void quickSort(vector<Person> &arr,int low,int high,
               bool (*cmp)(const Person&, const Person&)) {
    if(low<high) {
        int pi=partition(arr,low,high,cmp);
        quickSort(arr,low,pi-1,cmp);
        quickSort(arr,pi+1,high,cmp);
    }
}

/**
 * @brief Get maximum age in dataset
 */
int getMaxAge(vector<Person> &arr) {
    int mx = arr[0].age;
    for (auto &p : arr)
        if (p.age > mx) mx = p.age;
    return mx;
}

/**
 * @brief Counting sort based on digit (for radix sort on age)
 */
void countingSortAge(vector<Person> &arr, int exp) {
    int n = arr.size();
    vector<Person> output(n);
    int count[10] = {0};

    for (int i = 0; i < n; i++)
        count[(arr[i].age / exp) % 10]++;

    for (int i = 1; i < 10; i++)
        count[i] += count[i - 1];

    for (int i = n - 1; i >= 0; i--) {
        int idx = (arr[i].age / exp) % 10;
        output[count[idx] - 1] = arr[i];
        count[idx]--;
    }

    arr = output;
}

/**
 * @brief Radix sort based on age
 */
void radixSortAge(vector<Person> &arr) {
    int maxAge = getMaxAge(arr);
    for (int exp = 1; maxAge / exp > 0; exp *= 10)
        countingSortAge(arr, exp);
}

/**
 * @brief Get maximum string length in dataset
 */
int getMaxLen(vector<Person> &arr) {
    int mx = 0;
    for (auto &p : arr)
        if (p.name.length() > mx) mx = p.name.length();
    return mx;
}

/**
 * @brief Counting sort for characters (used in radix sort for name)
 */
void countingSortName(vector<Person> &arr, int pos) {
    int n = arr.size();
    vector<Person> output(n);
    int count[256] = {0};

    for (int i = 0; i < n; i++) {
        char ch = (pos < arr[i].name.length()) ? arr[i].name[pos] : 0;
        count[(int)ch]++;
    }

    for (int i = 1; i < 256; i++)
        count[i] += count[i - 1];

    for (int i = n - 1; i >= 0; i--) {
        char ch = (pos < arr[i].name.length()) ? arr[i].name[pos] : 0;
        output[count[(int)ch] - 1] = arr[i];
        count[(int)ch]--;
    }

    arr = output;
}

/**
 * @brief Radix sort based on name (lexicographic)
 */
void radixSortName(vector<Person> &arr) {
    int maxLen = getMaxLen(arr);
    for (int pos = maxLen - 1; pos >= 0; pos--)
        countingSortName(arr, pos);
}

/**
 * @brief Radix sort for name + age
 * First sorts by age, then by name (stable sorting)
 */
void radixSortNameAge(vector<Person> &arr) {
    radixSortAge(arr);
    radixSortName(arr);
}

/**
 * @brief Writes CSV header
 */
void writeHeader(ofstream &out) {
    out << "Dataset,"
        << "Ins_Name,Ins_Age,"
        << "Merge_Name,Merge_Age,"
        << "Quick_Name,Quick_Age,"
        << "Radix_Name,Radix_Age\n";
}

/**
 * @brief Writes sorted data into CSV
 */
void writeData(ofstream &out, int ds,
               vector<Person> &i,
               vector<Person> &m,
               vector<Person> &q,
               vector<Person> &r) {

    for(int k=0;k<i.size();k++) {
        out << ds << ","
            << i[k].name << "," << i[k].age << ","
            << m[k].name << "," << m[k].age << ","
            << q[k].name << "," << q[k].age << ","
            << r[k].name << "," << r[k].age << "\n";
    }
}

/**
 * @brief Main function: executes sorting and records time
 */
int main() {

    ofstream result("time_results.csv");
    result << "n,"
           << "Age_Ins,Age_Merge,Age_Quick,Age_Radix,"
           << "Name_Ins,Name_Merge,Name_Quick,Name_Radix,"
           << "Both_Ins,Both_Merge,Both_Quick,Both_Radix\n";

    for(int n=10;n<=100;n+=10) {

        double tIns=0, tMer=0, tQui=0, tRad=0;
        double tInsN=0, tMerN=0, tQuiN=0, tRadN=0;
        double tInsB=0, tMerB=0, tQuiB=0, tRadB=0;

        string inputFile="inputdata/data_n"+to_string(n)+".csv";

        ofstream ageFile("sorteddata/sorteddata_n_"+to_string(n)+"_age.csv");
        ofstream nameFile("sorteddata/sorteddata_n_"+to_string(n)+"_name.csv");
        ofstream bothFile("sorteddata/sorteddata_n_"+to_string(n)+"_nameage.csv");

        writeHeader(ageFile);
        writeHeader(nameFile);
        writeHeader(bothFile);

        for(int ds=1;ds<=10;ds++) {

            ifstream in(inputFile);
            vector<Person> arr;
            string line;

            getline(in,line);

            while(getline(in,line)) {
                stringstream ss(line);
                string token;
                int dno;
                Person p;

                getline(ss,token,','); dno=stoi(token);
                if(dno!=ds) continue;

                getline(ss,p.name,',');
                getline(ss,token,',');
                p.age=stoi(token);

                arr.push_back(p);
            }
            in.close();

            /* Sorting logic remains unchanged */
            auto i1=arr, m1=arr, q1=arr, r1=arr;

            auto start = high_resolution_clock::now();
            insertionSort(i1,cmpAge);
            auto end = high_resolution_clock::now();
            tIns += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            mergeSort(m1,0,m1.size()-1,cmpAge);
            end = high_resolution_clock::now();
            tMer += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            quickSort(q1,0,q1.size()-1,cmpAge);
            end = high_resolution_clock::now();
            tQui += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            radixSortAge(r1);
            end = high_resolution_clock::now();
            tRad += duration<double,milli>(end-start).count();

            writeData(ageFile,ds,i1,m1,q1,r1);

            auto i2=arr, m2=arr, q2=arr, r2=arr;

            start = high_resolution_clock::now();
            insertionSort(i2,cmpName);
            end = high_resolution_clock::now();
            tInsN += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            mergeSort(m2,0,m2.size()-1,cmpName);
            end = high_resolution_clock::now();
            tMerN += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            quickSort(q2,0,q2.size()-1,cmpName);
            end = high_resolution_clock::now();
            tQuiN += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            radixSortName(r2);
            end = high_resolution_clock::now();
            tRadN += duration<double,milli>(end-start).count();

            writeData(nameFile,ds,i2,m2,q2,r2);

            auto i3=arr, m3=arr, q3=arr, r3=arr;

            start = high_resolution_clock::now();
            insertionSort(i3,cmpNameAge);
            end = high_resolution_clock::now();
            tInsB += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            mergeSort(m3,0,m3.size()-1,cmpNameAge);
            end = high_resolution_clock::now();
            tMerB += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            quickSort(q3,0,q3.size()-1,cmpNameAge);
            end = high_resolution_clock::now();
            tQuiB += duration<double,milli>(end-start).count();

            start = high_resolution_clock::now();
            radixSortNameAge(r3);
            end = high_resolution_clock::now();
            tRadB += duration<double,milli>(end-start).count();

            writeData(bothFile,ds,i3,m3,q3,r3);
        }

        result << n << ","
               << tIns/10 << "," << tMer/10 << "," << tQui/10 << "," << tRad/10 << ","
               << tInsN/10 << "," << tMerN/10 << "," << tQuiN/10 << "," << tRadN/10 << ","
               << tInsB/10 << "," << tMerB/10 << "," << tQuiB/10 << "," << tRadB/10 << "\n";

        ageFile.close();
        nameFile.close();
        bothFile.close();
    }

    result.close();

    cout<<"All outputs + time analysis generated successfully.\n";
    return 0;
}
